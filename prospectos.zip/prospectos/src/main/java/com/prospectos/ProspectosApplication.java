package com.prospectos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProspectosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProspectosApplication.class, args);
	}

}
