package com.prospectos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProspectosApplicationTests {

	@Test
	void contextLoads() {
	}

}
